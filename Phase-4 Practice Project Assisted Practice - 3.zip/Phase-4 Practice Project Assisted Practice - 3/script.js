// IIFE example
(function() {
    var message = "This is an IIFE (Immediately Invoked Function Expression).";
    console.log(message);
  })();
  
  // Callback example
  function greet(name, callback) {
    var greeting = "Hello, " + name + "!";
    callback(greeting);
  }
  
  function displayGreeting(message) {
    document.getElementById("output").textContent = message;
  }
  
  function executeCallback() {
    var name = prompt("Enter your name:");
    if (name) {
      greet(name, displayGreeting);
    }
  }
  
  // Closure example
  function createCounter() {
    var count = 0;
  
    function increment() {
      count++;
      console.log("Count: " + count);
    }
  
    return increment;
  }
  
  var counter = createCounter();
  counter(); // Output: Count: 1
  counter(); // Output: Count: 2
  