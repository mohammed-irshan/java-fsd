// Student class
class Student {
    constructor(name, age, grade) {
      this.name = name;
      this.age = age;
      this.grade = grade;
    }
  
    displayInfo() {
      return "Name: " + this.name + ", Age: " + this.age + ", Grade: " + this.grade;
    }
  }
  
  // Map example
  var students = new Map();
  
  function createStudent() {
    var name = prompt("Enter student name:");
    var age = parseInt(prompt("Enter student age:"));
    var grade = prompt("Enter student grade:");
  
    var student = new Student(name, age, grade);
    students.set(name, student);
  }
  
  function displayStudents() {
    var output = "";
    students.forEach(function(student) {
      output += student.displayInfo() + "\n";
    });
    document.getElementById("output").textContent = output;
  }
  