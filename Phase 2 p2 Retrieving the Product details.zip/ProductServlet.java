import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/ProductServlet")
public class ProductServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws IOException {
        int productId = Integer.parseInt(request.getParameter("productId"));

        try {
            // Step 1: Load and register the JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Step 2: Establish a connection
            String jdbcURL = "jdbc:mysql://localhost:3306/productsdb";
            String username = "your_username";
            String password = "your_password";
            Connection connection = DriverManager.getConnection(jdbcURL, username, password);

            // Step 3: Create a statement
            String sql = "SELECT * FROM product WHERE id=?";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setInt(1, productId);

                // Step 4: Execute the query
                try (ResultSet resultSet = statement.executeQuery()) {
                    response.setContentType("text/html");
                    PrintWriter out = response.getWriter();

                    // Step 5: Process the result set
                    if (resultSet.next()) {
                        out.println("<h2>Product Details:</h2>");
                        out.println("<p>ID: " + resultSet.getInt("id") + "</p>");
                        out.println("<p>Name: " + resultSet.getString("name") + "</p>");
                        out.println("<p>Price: $" + resultSet.getDouble("price") + "</p>");
                        out.println("<p>Description: " + resultSet.getString("description") + "</p>");
                    } else {
                        out.println("<h2>Error: Product not found</h2>");
                    }
                }
            }

            // Step 6: Close the connection
            connection.close();

        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }
}
