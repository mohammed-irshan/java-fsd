package com.hyr.test;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Amazon {
    private WebDriver driver;

    @BeforeMethod
    public void setUp() {
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        driver.manage().window().maximize();
    }

    @AfterMethod
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }

    @Test
    public void LaunchApp() {
        driver.get("https://www.amazon.in");
    }

    @Test
    public void EnterRegistrationDetails() {
        driver.get("https://www.amazon.in");
        driver.findElement(By.linkText("Start here.")).click();
        driver.findElement(By.id("ap_customer_name")).sendKeys("Jyoshna");
        driver.findElement(By.id("ap_phone_number")).sendKeys("9381065969");
        driver.findElement(By.id("ap_email")).sendKeys("Jyoshna@gmail.com");
        driver.findElement(By.id("ap_password")).sendKeys("jyoshna");
        driver.findElement(By.id("continue")).click();
    }

    @Test
    public void EnterLoginDetails() {
        driver.get("https://www.amazon.in");
        driver.findElement(By.linkText("Sign in")).click();
        driver.findElement(By.id("ap_email")).sendKeys("9381065969");
        driver.findElement(By.id("continue")).click();
        driver.findElement(By.id("ap_password")).sendKeys("jyoshna");
        driver.findElement(By.id("signInSubmit")).click();
    }
}
