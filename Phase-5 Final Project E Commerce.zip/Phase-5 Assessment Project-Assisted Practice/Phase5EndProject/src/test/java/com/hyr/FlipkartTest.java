package com.hyr;
import java.util.List;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.List;

public class FlipkartTest {

    private WebDriver wd;

    @BeforeMethod
    public void setup() {
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\NEO\\Desktop\\Selenium_Jars\\chromedriver.exe");
        wd = new ChromeDriver();
    }

    @AfterMethod
    public void cleanup() {
        wd.quit();
    }

    @Test
    public void flipkartTesting() throws InterruptedException {
        System.out.println("Navigate to the home page");
        wd.get("https://www.flipkart.com/");
        wd.manage().window().maximize();
        WebDriverWait wait = new WebDriverWait(wd, 120); // Wait time in seconds (e.g., 120 seconds)
        System.out.println("Navigation done on Chrome\n");

        System.out.println("Searching for an item");
        WebElement textFieldRef = wd.findElement(By.name("q"));
        textFieldRef.sendKeys("Iphone 13");

        // Scroll the button into view
        WebElement buttonRef = wd.findElement(By.className("L0Z3Pu"));
        ((JavascriptExecutor) wd).executeScript("arguments[0].scrollIntoView(true);", buttonRef);

        // Click the button using the Actions class
        Actions actions = new Actions(wd);
        actions.moveToElement(buttonRef).click().perform();

        System.out.println("Search done successfully\n");

        System.out.println("Checking whether images are loaded");
        List<WebElement> images = wd.findElements(By.className("CXW8mj"));
        for (WebElement image : images) {
            Boolean imageLoaded = (Boolean) ((JavascriptExecutor) wd).executeScript(
                    "return arguments[0].complete && typeof arguments[0].naturalWidth != \"undefined\" && arguments[0].naturalWidth > 0",
                    image);
            if (imageLoaded != null && imageLoaded) {
                System.out.println("Image is present and loaded");
            } else {
                System.out.println("Image is not present or not loaded");
            }
        }
        System.out.println("The images are loaded and visible\n");

        System.out.println("Scrolling to the bottom of the page");
        JavascriptExecutor js = (JavascriptExecutor) wd;
        js.executeScript("window.scrollTo(0,document.body.scrollHeight)");
        System.out.println("Navigation to the bottom of the page done successfully\n");
    }
}
