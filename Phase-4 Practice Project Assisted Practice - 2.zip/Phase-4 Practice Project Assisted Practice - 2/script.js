// Function to display a greeting message
function sayHello() {
    var name = prompt("Enter your name:");
    if (name) {
      var greeting = "Hello, " + name + "!";
      document.getElementById("output").textContent = greeting;
    }
  }
  
  // Function to calculate the sum of two numbers
  function calculateSum() {
    var num1 = parseInt(prompt("Enter the first number:"));
    var num2 = parseInt(prompt("Enter the second number:"));
  
    if (!isNaN(num1) && !isNaN(num2)) {
      var sum = num1 + num2;
      document.getElementById("output").textContent = "The sum is: " + sum;
    } else {
      alert("Invalid input. Please enter valid numbers.");
    }
  }
  